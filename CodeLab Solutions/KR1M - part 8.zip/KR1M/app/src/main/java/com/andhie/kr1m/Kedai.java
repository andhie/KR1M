package com.andhie.kr1m;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by AgmoStudio on 31/10/2015.
 */
public class Kedai implements Parcelable {

    private String name;
    private String address;
    private String state;
    private String tel;
    private double lat;
    private double lng;

    public Kedai() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }

    //********************************************
    //START:  Methods to implement Parcelable    *
    //********************************************
    protected Kedai(Parcel in) {
        name = in.readString();
        address = in.readString();
        state = in.readString();
        tel = in.readString();
        lat = in.readDouble();
        lng = in.readDouble();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(address);
        dest.writeString(state);
        dest.writeString(tel);
        dest.writeDouble(lat);
        dest.writeDouble(lng);
    }

    @SuppressWarnings("unused")
    public static final Parcelable.Creator<Kedai> CREATOR = new Parcelable.Creator<Kedai>() {
        @Override
        public Kedai createFromParcel(Parcel in) {
            return new Kedai(in);
        }

        @Override
        public Kedai[] newArray(int size) {
            return new Kedai[size];
        }
    };

    //********************************************
    //  END:  Methods to implement Parcelable    *
    //********************************************
}
