package com.andhie.kr1m;

import android.app.IntentService;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by AgmoStudio on 01/11/2015.
 */
public class FetchKedaiService extends IntentService {

    public FetchKedaiService() {
        super("FetchKedaiService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        HttpURLConnection urlConnection = null;
        StringBuilder result = new StringBuilder();

        try {
            // create a URL from the string
            URL url = new URL("https://gist.githubusercontent.com/andhie/703343175d760b9cf42d/raw/ecb5fafb44522d54bfc760ea23fa04f16460eb74/kr1m.json");
            // open a connection to the server
            urlConnection = (HttpURLConnection) url.openConnection();
            // read the server response as a channel of bits and bytes
            InputStream in = new BufferedInputStream(urlConnection.getInputStream());

            // buffers the input stream to make it efficient when reading it
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));

            // read every line until the end
            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line);
            }

            // disconnect
            urlConnection.disconnect();


            // start parsing the JSON string
            String jsonString = result.toString();
            Log.i("json", jsonString);

            // create an instance to DB and get a writable DB
            DatabaseHelper dbHelper = new DatabaseHelper(this);
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            db.beginTransaction();

            // the data begins with "[" means an Array
            JSONArray jsonArray = new JSONArray(jsonString);
            // treat it like usual array/list, just loop thru the end
            for (int i = 0, size = jsonArray.length(); i < size; i++) {
                // get each object out
                JSONObject obj = jsonArray.getJSONObject(i);

                // extract the values based on the Key that we know
                // sample JSON data:
                //
                // { "address" : "LRT Stesen Kelana Jaya",
                //   "id" : 1,
                //   "latitude" : 3.1127889999999998,
                //   "longitude" : 101.604116,
                //   "name" : "Kedai Rakyat 1 Malaysia LRT Kelana Jaya",
                //   "state" : "SELANGOR",
                //   "tel" : "03-21062815"
                // }
                //
                ContentValues cv = new ContentValues();
                cv.put(DatabaseHelper.NAME, obj.getString("name"));
                cv.put(DatabaseHelper.ADDRESS, obj.getString("address"));
                cv.put(DatabaseHelper.STATE, obj.getString("state"));
                cv.put(DatabaseHelper.TEL, obj.getString("tel"));
                cv.put(DatabaseHelper.LAT, obj.getDouble("latitude"));
                cv.put(DatabaseHelper.LNG, obj.getDouble("longitude"));

                // insert in our database
                db.insert(DatabaseHelper.TABLE_NAME, null, cv);
            }

            // declare our transaction is successful
            db.setTransactionSuccessful();
            // commit any successful transaction
            db.endTransaction();

            // remember to close our DB
            db.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        // create an intent to notify we got new data
        Intent data = new Intent("ACTION_DATA_UPDATED");

        // Broadcast our result
        LocalBroadcastManager.getInstance(this)
                .sendBroadcast(data);
    }
}
