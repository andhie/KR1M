package com.andhie.kr1m;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

/**
 * Created by AgmoStudio on 31/10/2015.
 */
public class CustomAdapter extends ArrayAdapter<Kedai> {

    public CustomAdapter(Context context) {
        super(context, 0);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder;
        if (convertView == null) {
            // inflate our XML layout into Java code
            convertView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.list_item_kedai, parent, false);

            // save processing power from always findViewById
            holder = new ViewHolder();
            holder.kedaiName = (TextView) convertView.findViewById(R.id.kedai_name);
            holder.kedaiAddress = (TextView) convertView.findViewById(R.id.kedai_address);

            // setTag and getTag is a easy way to hold data
            // without needing things like array
            convertView.setTag(holder);
        } else {
            // we retrieve back out ViewHolder from convertView which we tagged earlier
            holder = (ViewHolder) convertView.getTag();
        }

        // get the Kedai item from the adapter
        Kedai kedai = getItem(position);

        // update all the views that we need
        holder.kedaiName.setText(kedai.getName());
        holder.kedaiAddress.setText(kedai.getAddress());

        // return our updated view
        return convertView;

    }

    /**
     * Use ViewHolder patterns to save processing power from always findViewById everytime
     */
    private static class ViewHolder {
        TextView kedaiName;
        TextView kedaiAddress;
    }
}
