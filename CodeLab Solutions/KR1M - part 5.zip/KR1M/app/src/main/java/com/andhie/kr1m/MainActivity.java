package com.andhie.kr1m;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private CustomAdapter adapter;
    BroadcastReceiver broadcastReceiver = new MyBroadcastReceiver();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // find the listview
        ListView listView = (ListView) findViewById(R.id.listView);

        // create adapter and set it to our listview
        adapter = new CustomAdapter(this);
        listView.setAdapter(adapter);

        // react to any clicks on list items
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // parent can be any Adapter-based view such as ListView, Spinner
                // we also can get Kedai directly via adapter.getItem()
                Kedai kedai = (Kedai) parent.getAdapter().getItem(position);

                Intent intent = new Intent(parent.getContext(), KedaiDetailActivity.class);
                // we are passing Kedai as Parcelable data-type; Kedai implements Parcelable
                intent.putExtra("kedai_data", kedai);
                ActivityCompat.startActivity(MainActivity.this, intent, null);
            }
        });

        // start our service to fetch data
        Intent intent = new Intent(this, FetchKedaiService.class);
        startService(intent);

        // we try to load our data from DB while waiting for our service to update data
        // so users wont have to wait a long time to see something. Good User Experience!
        new ReadDBTask().execute();

    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter("ACTION_DATA_UPDATED");
        LocalBroadcastManager.getInstance(this)
                .registerReceiver(broadcastReceiver, filter);
    }

    @Override
    protected void onStop() {
        super.onStop();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(broadcastReceiver);
    }

    public class MyBroadcastReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            // we have change our behavior to only listen to "ACTION_DATA_UPDATED"
            // we just interpret it as reloading data from DB
            new ReadDBTask().execute();
        }
    }

    public class ReadDBTask extends AsyncTask<Void, Void, List<Kedai>> {

        @Override
        protected List<Kedai> doInBackground(Void... args) {

            List<Kedai> kedaiList = new ArrayList<>();

            DatabaseHelper dbHelper = new DatabaseHelper(getApplicationContext());
            SQLiteDatabase db = dbHelper.getReadableDatabase();

            Cursor cursor = db.query(DatabaseHelper.TABLE_NAME, //query from kedai_table
                    null, // null means all columns. eg `new String[] {DatabaseHelper.Lat, ...}`
                    null, // null means no WHERE clause. eg `" DatabaseHelper.STATE=?"
                    null, // null because we have no args, eg `new String[] {"SELANGOR"}`
                    null, // null means we dont want to groupBy
                    null, // null means we dont want to filter having
                    null);// null means dont want to orderBy. eg. `DatabaseHelper.STATE + " DESC";

            // need to find out the index of the column in this cursor
            // e.g. when query, submitting column `new String[] {DatabaseHelper.Lng, DatabaseHelper.Lat}
            // Lng will be at column 0, lat will be column 1
            int nameColIndex = cursor.getColumnIndex(DatabaseHelper.NAME);
            int addressColIndex = cursor.getColumnIndex(DatabaseHelper.ADDRESS);
            int stateColIndex = cursor.getColumnIndex(DatabaseHelper.STATE);
            int telColIndex = cursor.getColumnIndex(DatabaseHelper.TEL);
            int latColIndex = cursor.getColumnIndex(DatabaseHelper.LAT);
            int lngColIndex = cursor.getColumnIndex(DatabaseHelper.LNG);

            // loop thru our Cursor to read each row
            while (cursor.moveToNext()) {
                Kedai kedai = new Kedai();
                kedai.setName(cursor.getString(nameColIndex));
                kedai.setAddress(cursor.getString(addressColIndex));
                kedai.setState(cursor.getString(stateColIndex));
                kedai.setTel(cursor.getString(telColIndex));
                kedai.setLat(cursor.getDouble(latColIndex));
                kedai.setLng(cursor.getDouble(lngColIndex));

                // add it to our list
                kedaiList.add(kedai);
            }

            // close the cursor
            cursor.close();

            // dont forget to close DB
            db.close();

            // return the list back to the Main/UI thread
            return kedaiList;
        }

        @Override
        protected void onPostExecute(List<Kedai> result) {
            // onPostExecute runs on Main/UI thread
            // we are safe to update our Views
            if (result != null) {
                adapter.clear();
                adapter.addAll(result);
            } else {
                Toast.makeText(MainActivity.this, "Error Getting Data", Toast.LENGTH_SHORT).show();
            }
        }

    }
}
