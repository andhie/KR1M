package com.andhie.kr1m;

import android.app.IntentService;
import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

/**
 * Created by AgmoStudio on 01/11/2015.
 */
public class FetchKedaiService extends IntentService {

    public FetchKedaiService() {
        super("FetchKedaiService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        HttpURLConnection urlConnection = null;
        List<Kedai> kedaiList = null;
        StringBuilder result = new StringBuilder();

        try {
            // create a URL from the string
            URL url = new URL("https://gist.githubusercontent.com/andhie/703343175d760b9cf42d/raw/ecb5fafb44522d54bfc760ea23fa04f16460eb74/kr1m.json");
            // open a connection to the server
            urlConnection = (HttpURLConnection) url.openConnection();
            // read the server response as a channel of bits and bytes
            InputStream in = new BufferedInputStream(urlConnection.getInputStream());

            // buffers the input stream to make it efficient when reading it
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));

            // read every line until the end
            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
        }

        // start parsing the JSON string
        String jsonString = result.toString();
        Log.i("json", jsonString);

        // create an intent and store our JSON data to be sent over
        Intent data = new Intent("ACTION_DATA_GET");
        data.putExtra("kedai_json", jsonString);

        // Broadcast our result
        LocalBroadcastManager.getInstance(this)
                .sendBroadcast(data);
    }
}
