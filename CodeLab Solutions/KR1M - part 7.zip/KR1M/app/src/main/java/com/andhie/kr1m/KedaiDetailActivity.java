package com.andhie.kr1m;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class KedaiDetailActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView call;
    private Kedai kedai;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kedai_detail);

        // find all views
        TextView kedaiName = (TextView) findViewById(R.id.kedai_name);
        TextView kedaiAddress = (TextView) findViewById(R.id.kedai_address);
        TextView kedaiState = (TextView) findViewById(R.id.kedai_state);
        call = (TextView) findViewById(R.id.call);
        TextView map = (TextView) findViewById(R.id.show_map);

        // set out click listener, our Activity implements onClickListener
        // so we use 'this' (refers to the activity)
        call.setOnClickListener(this);
        map.setOnClickListener(this);

        // the key "kedai_data" must match what was send over
        // its better to declare it as a 'static final String'
        kedai = getIntent().getParcelableExtra("kedai_data");

        kedaiName.setText(kedai.getName());
        kedaiAddress.setText(kedai.getAddress());
        kedaiState.setText(kedai.getState());
        call.setText(kedai.getTel());
    }

    @Override
    public void onClick(View v) {
        if (v == call) {
            String number = "tel:" + call.getText();

            // we use ACTION_DIAL instead of ACTION_CALL.
            // Call requires 'dangerous' permission, your app makes the call
            // Dial will just launch the phone's Dialer app, user will need to click to call
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse(number));
            startActivity(intent);
        } else if (v.getId() == R.id.show_map) {
            Intent intent = new Intent(this, GoogleMapsActivity.class);
            intent.putExtra("kedai_data", kedai);
            startActivity(intent);
        }
    }
}
