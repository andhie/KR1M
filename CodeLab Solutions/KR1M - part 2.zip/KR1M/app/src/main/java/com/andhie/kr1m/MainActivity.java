package com.andhie.kr1m;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private CustomAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // find the listview
        ListView listView = (ListView) findViewById(R.id.listView);

        // create adapter and set it to our listview
        adapter = new CustomAdapter(this);
        listView.setAdapter(adapter);

        // react to any clicks on list items
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // parent can be any Adapter-based view such as ListView, Spinner
                // we also can get Kedai directly via adapter.getItem()
                Kedai kedai = (Kedai) parent.getAdapter().getItem(position);

                Intent intent = new Intent(parent.getContext(), KedaiDetailActivity.class);
                // we are passing Kedai as Parcelable data-type; Kedai implements Parcelable
                intent.putExtra("kedai_data", kedai);
                startActivity(intent);
            }
        });

        // run fetch data task
        new FetchData().execute();
    }

    public class FetchData extends AsyncTask<String, Void, List<Kedai>> {

        @Override
        protected List<Kedai> doInBackground(String... args) {
            // doInBackground runs on separate thread,
            // only the Main/UI thread is allow to update the UI
            // NOTE: updating the UI here will cause app crash
            //       e.g. textview.settext()

            HttpURLConnection urlConnection = null;
            List<Kedai> kedaiList = null;
            StringBuilder result = new StringBuilder();

            try {
                // create a URL from the string
                URL url = new URL("https://gist.githubusercontent.com/andhie/703343175d760b9cf42d/raw/ecb5fafb44522d54bfc760ea23fa04f16460eb74/kr1m.json");
                // open a connection to the server
                urlConnection = (HttpURLConnection) url.openConnection();
                // read the server response as a channel of bits and bytes
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());

                // buffers the input stream to make it efficient when reading it
                BufferedReader reader = new BufferedReader(new InputStreamReader(in));

                // read every line until the end
                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }

                // start parsing the JSON string
                String jsonString = result.toString();
                kedaiList = new ArrayList<>();

                // the data begins with "[" means an Array
                JSONArray jsonArray = new JSONArray(jsonString);
                // treat it like usual array/list, just loop thru the end
                for (int i = 0, size = jsonArray.length(); i < size; i++) {
                    // get each object out
                    JSONObject obj = jsonArray.getJSONObject(i);

                    // extract the values based on the Key that we know
                    // sample JSON data:
                    //
                    // { "address" : "LRT Stesen Kelana Jaya",
                    //   "id" : 1,
                    //   "latitude" : 3.1127889999999998,
                    //   "longitude" : 101.604116,
                    //   "name" : "Kedai Rakyat 1 Malaysia LRT Kelana Jaya",
                    //   "state" : "SELANGOR",
                    //   "tel" : "03-21062815"
                    // }
                    //
                    Kedai kedai = new Kedai();
                    kedai.setName(obj.getString("name"));
                    kedai.setAddress(obj.getString("address"));
                    kedai.setState(obj.getString("state"));
                    kedai.setTel(obj.getString("tel"));
                    kedai.setLat(obj.getDouble("latitude"));
                    kedai.setLng(obj.getDouble("longitude"));

                    // add it to our list
                    kedaiList.add(kedai);
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
            }

            // return the list back to the Main/UI thread
            return kedaiList;
        }

        @Override
        protected void onPostExecute(List<Kedai> result) {
            // onPostExecute runs on Main/UI thread
            // we are safe to update our Views
            if (result != null) {
                adapter.clear();
                adapter.addAll(result);
            } else {
                Toast.makeText(MainActivity.this, "Error Getting Data", Toast.LENGTH_SHORT).show();
            }
        }

    }
}
