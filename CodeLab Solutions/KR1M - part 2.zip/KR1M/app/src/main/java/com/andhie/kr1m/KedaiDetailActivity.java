package com.andhie.kr1m;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class KedaiDetailActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView kedaiName;
    private TextView kedaiAddress;
    private TextView kedaiState;
    private TextView call;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kedai_detail);

        // find all views
        kedaiName = (TextView) findViewById(R.id.kedai_name);
        kedaiAddress = (TextView) findViewById(R.id.kedai_address);
        kedaiState = (TextView) findViewById(R.id.kedai_state);
        call = (TextView) findViewById(R.id.call);

        // set out click listener, our Activity implements onClickListener
        // so we use 'this' (refers to the activity)
        call.setOnClickListener(this);

        // the key "kedai_data" must match what was send over
        // its better to declare it as a 'static final String'
        Kedai kedai = getIntent().getParcelableExtra("kedai_data");

        kedaiName.setText(kedai.getName());
        kedaiAddress.setText(kedai.getAddress());
        kedaiState.setText(kedai.getState());
        call.setText(kedai.getTel());
    }

    @Override
    public void onClick(View v) {
        if (v == call) {
            String number = "tel:" + call.getText();

            // we use ACTION_DIAL instead of ACTION_CALL.
            // Call requires 'dangerous' permission, your app makes the call
            // Dial will just launch the phone's Dialer app, user will need to click to call
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse(number));
            startActivity(intent);
        }
    }
}
