package com.andhie.kr1m;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // find the listview
        ListView listView = (ListView) findViewById(R.id.listView);

        CustomAdapter adapter = new CustomAdapter(this);
        listView.setAdapter(adapter);

        // we put dummy data set into our Adapter
        for (int i = 0; i < 10; i++) {
            // create a kedai
            Kedai kedai = new Kedai();
            kedai.setName("Kedai " + i);
            kedai.setAddress("Address " + i);

            // add it into our adapter
            adapter.add(kedai);
        }

    }
}
